package com.oyosite.ticon.radiocraft.init;

import java.util.List;


import com.oyosite.ticon.radiocraft.objects.items.ItemBase;
import com.oyosite.ticon.radiocraft.objects.items.RadioShard;
import com.oyosite.ticon.radiocraft.util.Reference;
import com.oyosite.ticon.radiocraft.util.Utils;

import java.util.ArrayList;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.color.IItemColor;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSeeds;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ItemInit {
	public static Item radio_shard;
	
	
	public static void init() {
		radio_shard = new RadioShard("radio_shard", "radio_shard");
	}
	
	public static void register() {
		registerItem(radio_shard);
	}

	public static void registerRenders() {
		registerRender(radio_shard);
	}
	
	public static void registerItem(Item item) {
		GameRegistry.register(item);
		Utils.getLogger().info("Registered Item: " + item.getUnlocalizedName().substring(5));
	}
	
	public static void registerRender(Item item) {
		ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(new ResourceLocation(Reference.MODID, item.getUnlocalizedName().substring(5)), "inventory"));
		Utils.getLogger().info("Registered render for " + item.getUnlocalizedName().substring(5));
	}

	
}
