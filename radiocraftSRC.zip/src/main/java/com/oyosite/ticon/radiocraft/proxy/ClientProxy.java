package com.oyosite.ticon.radiocraft.proxy;

import com.oyosite.ticon.radiocraft.init.ItemInit;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.model.ModelLoader;

public class ClientProxy extends CommonProxy{
	
	public void registerRenders() {
		ItemInit.registerRenders();
	}
}
