package com.oyosite.ticon.radiocraft.objects.items;

import com.oyosite.ticon.radiocraft.init.ItemInit;
import com.oyosite.ticon.radiocraft.util.Reference;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;

public class RadioShard extends Item{
	
	

	public RadioShard(String unlocalizedName, String registryName) {
		this.setUnlocalizedName(unlocalizedName);
		this.setRegistryName(new ResourceLocation(Reference.MODID, registryName));
		
	}

	
}
