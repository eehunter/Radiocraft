package com.oyosite.ticon.radiocraft.init;

import java.util.ArrayList;
import java.util.List;

import com.oyosite.ticon.radiocraft.objects.BlockBase;

//import harry.mod.objects.blocks.BlockBase;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockInit {
	public static final List<Block> BLOCKS = new ArrayList<Block>();
	
	public static final Block RADIO_STONE = new BlockBase("block_copper", Material.IRON);
	
	//public static final Block ORE_END = new BlockOres("ore_end", "end");
	//public static final Block ORE_OVERWORLD = new BlockOres("ore_overworld", "overworld");
	//public static final Block ORE_NETHER = new BlockOres("ore_nether", "nether");
	
	//public static final Block PLANKS = new BlockPlank("planks");
	//public static final Block LOGS = new BlockLogs("log");
	//public static final Block LEAVES = new BlockLeaf("leaves");
	//public static final Block SAPLINGS = new BlockSaplings("sapling");
	
	//public static final Block DIRT = new BlockDirts("dirt");
}
