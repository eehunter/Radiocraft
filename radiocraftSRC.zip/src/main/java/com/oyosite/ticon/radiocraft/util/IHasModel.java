package com.oyosite.ticon.radiocraft.util;

public interface IHasModel {
	public void registerModels();
}
