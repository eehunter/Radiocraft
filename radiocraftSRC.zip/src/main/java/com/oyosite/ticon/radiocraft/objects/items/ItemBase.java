package com.oyosite.ticon.radiocraft.objects.items;

import com.oyosite.ticon.radiocraft.Main;
import com.oyosite.ticon.radiocraft.init.ItemInit;
import com.oyosite.ticon.radiocraft.proxy.ClientProxy;
import com.oyosite.ticon.radiocraft.util.IHasModel;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class ItemBase extends Item implements IHasModel{

	@Override
	public void registerModels() {
		// TODO Auto-generated method stub
		
	}

	

}
