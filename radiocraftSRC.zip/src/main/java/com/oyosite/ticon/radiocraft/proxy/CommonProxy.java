package com.oyosite.ticon.radiocraft.proxy;

import com.oyosite.ticon.radiocraft.init.ItemInit;

import net.minecraft.item.Item;

public class CommonProxy {

	public void registerItemRenderer(Item item, int meta, String id) {}
	public void registerVariantRenderer(Item item, int meta, String filename, String id) {}
	public void registerRenders() {
		
	}
}
