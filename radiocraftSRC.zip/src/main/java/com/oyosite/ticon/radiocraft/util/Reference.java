package com.oyosite.ticon.radiocraft.util;

public class Reference {
public static final String MODID = "rc";
public static final String NAME = "Radiocraft";
public static final String VERSION = "PreAlpha";
public static final String CLIENT = "com.oyosite.ticon.radiocraft.proxy.ClientProxy";
public static final String COMMON = "com.oyosite.ticon.radiocraft.proxy.CommonProxy";
}
